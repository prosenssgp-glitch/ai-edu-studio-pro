package com.aiedu.studio

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

// ---------- Colors matching the original prototype's CSS variables ----------
private val BgColor = Color(0xFF080B10)
private val PanelColor = Color(0xFF111720)
private val Panel2Color = Color(0xFF171E29)
private val LineColor = Color(0xFF273140)
private val TextColor = Color(0xFFEEF3F8)
private val MutedColor = Color(0xFF8793A4)
private val BlueColor = Color(0xFF2D75FF)
private val GreenColor = Color(0xFF6EE7B7)
private val YellowColor = Color(0xFFFFD277)
private val TopBarColor = Color(0xFF0E131B)

data class ClipItem(val label: String, val color: Color)
data class PanelCard(val title: String, val subtitle: String)

private val panels: Map<String, List<PanelCard>> = mapOf(
    "Media" to listOf(
        PanelCard("Import Media", "Video, images and 100+ photos"),
        PanelCard("Stock Library", "Licensed music, SFX, images and video"),
        PanelCard("Screen Recording", "Record lessons and tutorials")
    ),
    "Layer" to listOf(
        PanelCard("Text", "Titles, captions and subtitles"),
        PanelCard("Sticker & Shape", "Arrows, circles and highlights"),
        PanelCard("Drawing", "Freehand annotations")
    ),
    "Audio" to listOf(
        PanelCard("Music", "Beat sync and volume automation"),
        PanelCard("SFX", "Quiz and transition sounds"),
        PanelCard("Mixer", "Ducking and cleanup")
    ),
    "Voice" to listOf(
        PanelCard("AI Voice", "Natural voiceover, speed and pauses"),
        PanelCard("Record Voice", "Your own commentary"),
        PanelCard("Voice Isolation", "Clean dialogue")
    ),
    "AI Studio" to listOf(
        PanelCard("AI Auto Edit", "Create an editable first draft"),
        PanelCard("AI Quiz Maker", "5\u2013100 questions with explanations"),
        PanelCard("AI Captions", "Editable captions"),
        PanelCard("AI B-Roll", "Suggested visual layers"),
        PanelCard("AI Thumbnail", "Editable thumbnail variations"),
        PanelCard("AI Value Check", "Prompt for original creator value")
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = BgColor)) {
                EditorScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    fun toast(message: String) {
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
        }
    }

    var selectedClip by remember { mutableStateOf("Quiz Text") }
    var opacity by remember { mutableFloatStateOf(100f) }
    var scale by remember { mutableFloatStateOf(100f) }
    var isPlaying by remember { mutableStateOf(false) }
    var clockSeconds by remember { mutableFloatStateOf(0f) }
    var activePanel by remember { mutableStateOf<String?>(null) }
    var activeTab by remember { mutableStateOf("Edit") }

    // Real imported media (Storage Access Framework) — replaces the placeholder demo scene
    // in the preview with actual video playback once the user picks a file.
    var importedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var videoClips by remember { mutableStateOf(listOf(ClipItem("Main Video", Color(0xFF304865)))) }

    // Real trim range (milliseconds) over the imported clip, and export state.
    var videoDurationMs by remember { mutableLongStateOf(0L) }
    var trimStartMs by remember { mutableFloatStateOf(0f) }
    var trimEndMs by remember { mutableFloatStateOf(0f) }
    var isExporting by remember { mutableStateOf(false) }

    // ExoPlayer lives here (not inside PreviewBox) so Trim/Export can read its duration
    // and control playback directly.
    val exoPlayer = remember(importedVideoUri) {
        importedVideoUri?.let { uri ->
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
            }
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                if (player.duration > 0 && videoDurationMs == 0L) {
                    videoDurationMs = player.duration
                    trimStartMs = 0f
                    trimEndMs = player.duration.toFloat()
                }
            }
        }
        exoPlayer?.addListener(listener)
        onDispose {
            exoPlayer?.removeListener(listener)
            exoPlayer?.release()
        }
    }

    // Reset trim range whenever a new clip is imported
    LaunchedEffect(importedVideoUri) {
        videoDurationMs = 0L
        trimStartMs = 0f
        trimEndMs = 0f
    }

    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            importedVideoUri = uri
            videoClips = videoClips + ClipItem("Imported Clip ${videoClips.size}", Color(0xFF304865))
            selectedClip = "Imported Clip"
            isPlaying = false
            toast("Video imported")
        }
    }

    fun runExport() {
        val uri = importedVideoUri
        if (uri == null) {
            toast("Import a video first, then Export")
            return
        }
        if (isExporting) return
        isExporting = true
        toast("Exporting trimmed video\u2026")

        val outDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AIEduStudio")
        outDir.mkdirs()
        val outputFile = File(outDir, "export_${System.currentTimeMillis()}.mp4")

        val clippedItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(trimStartMs.toLong())
                    .setEndPositionMs(if (trimEndMs > trimStartMs) trimEndMs.toLong() else videoDurationMs)
                    .build()
            )
            .build()

        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    isExporting = false
                    toast("Exported \u2192 Android/data/com.aiedu.studio/files/Movies/AIEduStudio/${outputFile.name}")
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    isExporting = false
                    toast("Export failed: ${exportException.message}")
                }
            })
            .build()

        transformer.start(clippedItem, outputFile.absolutePath)
    }

    Scaffold(
        containerColor = BgColor,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopBar(
                onBack = { toast("Project saved") },
                onUndo = { toast("Nothing to undo") },
                onRedo = { toast("Nothing to redo") },
                onExport = {
                    if (importedVideoUri != null) runExport()
                    else toast("Pre-export checks complete \u2022 Import a video to enable real export")
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Preview + Inspector
            Column(modifier = Modifier.padding(10.dp)) {
                PreviewBox(
                    isPlaying = isPlaying,
                    clockSeconds = clockSeconds,
                    opacity = opacity,
                    scale = scale,
                    videoUri = importedVideoUri,
                    exoPlayer = exoPlayer,
                    onPlayToggle = {
                        isPlaying = !isPlaying
                        toast(if (isPlaying) "Preview playing" else "Preview paused")
                    },
                    onSeek = { clockSeconds = it }
                )
                if (importedVideoUri != null && videoDurationMs > 0) {
                    Spacer(Modifier.height(10.dp))
                    TrimBar(
                        durationMs = videoDurationMs,
                        trimStartMs = trimStartMs,
                        trimEndMs = trimEndMs,
                        onTrimStartChange = {
                            trimStartMs = it.coerceAtMost(trimEndMs - 200f).coerceAtLeast(0f)
                            exoPlayer?.seekTo(trimStartMs.toLong())
                        },
                        onTrimEndChange = {
                            trimEndMs = it.coerceAtLeast(trimStartMs + 200f).coerceAtMost(videoDurationMs.toFloat())
                        }
                    )
                }
                Spacer(Modifier.height(10.dp))
                InspectorPanel(
                    selectedName = selectedClip,
                    activeTab = activeTab,
                    onTabChange = { activeTab = it },
                    opacity = opacity,
                    onOpacityChange = { opacity = it },
                    scale = scale,
                    onScaleChange = { scale = it },
                    onClose = { toast("Manual inspector remains available") },
                    onTool = { tool ->
                        if (tool == "Trim" && importedVideoUri != null) {
                            toast("Drag the trim handles above the preview")
                        } else {
                            toast("$tool ready for manual adjustment")
                        }
                    },
                    onReplaceMedia = { pickVideoLauncher.launch("video/*") },
                    onDeleteLayer = {
                        importedVideoUri = null
                        videoClips = listOf(ClipItem("Main Video", Color(0xFF304865)))
                        toast("Layer removed")
                    }
                )
            }

            // Action bar
            ActionBar(onOpenPanel = { activePanel = it })

            // Timeline
            TimelineSection(
                videoClips = videoClips,
                onSelect = { selectedClip = it },
                onZoom = { toast(it) }
            )

            // AI Studio / tool drawer
            activePanel?.let { key ->
                PanelDrawer(
                    title = key,
                    cards = panels[key].orEmpty(),
                    onClose = { activePanel = null },
                    onOpenCard = { cardTitle ->
                        if (key == "Media" && cardTitle == "Import Media") {
                            pickVideoLauncher.launch("video/*")
                        } else {
                            toast("$cardTitle needs a backend/AI integration \u2014 not built yet")
                        }
                    }
                )
            }

            // Safety / policy check
            SafetyCheck()

            Spacer(Modifier.height(20.dp))
        }
    }

    // Enforce the trim range live during preview playback, and drive the on-screen clock
    // from the real player position once a clip is loaded.
    LaunchedEffect(isPlaying, exoPlayer, trimEndMs) {
        if (exoPlayer == null) {
            while (isPlaying) {
                delay(1000)
                clockSeconds = if (clockSeconds >= 60f) 0f else clockSeconds + 1f
            }
        } else {
            while (isPlaying) {
                delay(200)
                val posMs = exoPlayer.currentPosition
                clockSeconds = (posMs / 1000f)
                if (trimEndMs > 0 && posMs >= trimEndMs) {
                    isPlaying = false
                    exoPlayer.pause()
                    exoPlayer.seekTo(trimStartMs.toLong())
                }
            }
        }
    }
}

@Composable
private fun TopBar(
    onBack: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onExport: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TopBarColor)
            .border(BorderStroke1(LineColor), shape = RoundedCornerShape(0.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IconButtonSquare(Icons.Filled.ArrowBack, onClick = onBack)
        Column {
            Text("AI EDU", color = TextColor, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 2.sp)
            Text("STUDIO PRO", color = MutedColor, fontSize = 7.sp, letterSpacing = 1.5.sp)
        }
        Text(
            "My Educational Video",
            color = Color(0xFFAEB8C6),
            fontSize = 12.sp,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        IconButtonSquare(Icons.Filled.Undo, onClick = onUndo)
        IconButtonSquare(Icons.Filled.Redo, onClick = onRedo)
        Button(
            onClick = onExport,
            colors = ButtonDefaults.buttonColors(containerColor = BlueColor, contentColor = Color.White),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)
        ) {
            Text("Export", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun IconButtonSquare(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Panel2Color)
            .border(BorderStroke1(LineColor), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick, modifier = Modifier.size(36.dp)) {
            Icon(icon, contentDescription = null, tint = TextColor)
        }
    }
}

@Composable
private fun PreviewBox(
    isPlaying: Boolean,
    clockSeconds: Float,
    opacity: Float,
    scale: Float,
    videoUri: Uri?,
    exoPlayer: ExoPlayer?,
    onPlayToggle: () -> Unit,
    onSeek: (Float) -> Unit
) {
    LaunchedEffect(isPlaying, exoPlayer) {
        exoPlayer?.playWhenReady = isPlaying
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(TopBarColor, RoundedCornerShape(12.dp))
            .border(BorderStroke1(LineColor), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(7.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF243C68), Color(0xFF0A0E16)),
                        radius = 900f
                    )
                )
        ) {
            if (exoPlayer != null) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            player = exoPlayer
                        }
                    }
                )
            } else {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.graphicsAlphaScale(opacity, scale)
                    ) {
                        Text(
                            "QUESTION 01",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier
                                .background(BlueColor, RoundedCornerShape(99.dp))
                                .padding(horizontal = 11.dp, vertical = 6.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Can you solve this?",
                            color = TextColor,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text("Choose the correct answer", color = Color(0xFFBDC7D4), fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("A", "B", "C", "D").forEach { letter ->
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(letter, color = Color(0xFF101319), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Playback bar
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0xDB070A0E))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(27.dp)
                        .clip(CircleShape)
                        .background(BlueColor),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = onPlayToggle, modifier = Modifier.size(27.dp)) {
                        Icon(
                            if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                }
                Text(formatClock(clockSeconds), color = TextColor, fontSize = 9.sp)
                Slider(
                    value = clockSeconds,
                    onValueChange = onSeek,
                    valueRange = 0f..60f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = BlueColor, activeTrackColor = BlueColor)
                )
                Text("01:00", color = TextColor, fontSize = 9.sp)
            }
        }
    }
}

private fun formatClock(seconds: Float): String {
    val s = seconds.toInt().coerceIn(0, 60)
    return "00:" + s.toString().padStart(2, '0')
}

@Composable
private fun TrimBar(
    durationMs: Long,
    trimStartMs: Float,
    trimEndMs: Float,
    onTrimStartChange: (Float) -> Unit,
    onTrimEndChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelColor, RoundedCornerShape(10.dp))
            .border(BorderStroke1(LineColor), RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Text("Trim (real \u2014 applied on Export)", color = TextColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Start", color = MutedColor, fontSize = 9.sp, modifier = Modifier.width(40.dp))
            Slider(
                value = trimStartMs,
                onValueChange = onTrimStartChange,
                valueRange = 0f..durationMs.toFloat(),
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = GreenColor, activeTrackColor = GreenColor)
            )
            Text(formatMs(trimStartMs), color = MutedColor, fontSize = 9.sp, modifier = Modifier.width(44.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("End", color = MutedColor, fontSize = 9.sp, modifier = Modifier.width(40.dp))
            Slider(
                value = trimEndMs,
                onValueChange = onTrimEndChange,
                valueRange = 0f..durationMs.toFloat(),
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = YellowColor, activeTrackColor = YellowColor)
            )
            Text(formatMs(trimEndMs), color = MutedColor, fontSize = 9.sp, modifier = Modifier.width(44.dp))
        }
    }
}

private fun formatMs(ms: Float): String {
    val totalSec = (ms / 1000).toInt().coerceAtLeast(0)
    val m = totalSec / 60
    val s = totalSec % 60
    return "$m:" + s.toString().padStart(2, '0')
}

@Composable
private fun InspectorPanel(
    selectedName: String,
    activeTab: String,
    onTabChange: (String) -> Unit,
    opacity: Float,
    onOpacityChange: (Float) -> Unit,
    scale: Float,
    onScaleChange: (Float) -> Unit,
    onClose: () -> Unit,
    onTool: (String) -> Unit,
    onReplaceMedia: () -> Unit,
    onDeleteLayer: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelColor, RoundedCornerShape(12.dp))
            .border(BorderStroke1(LineColor), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(selectedName, color = TextColor, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Filled.Close, contentDescription = null, tint = TextColor)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Edit", "Animation", "Color").forEach { tab ->
                val active = tab == activeTab
                Button(
                    onClick = { onTabChange(tab) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (active) BlueColor else Panel2Color,
                        contentColor = TextColor
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Text(tab, fontSize = 11.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        LabeledSlider("Opacity", opacity, 0f..100f, onOpacityChange)
        LabeledSlider("Scale", scale, 50f..150f, onScaleChange)
        Spacer(Modifier.height(6.dp))
        val tools = listOf("Trim", "Split", "Crop", "Rotate", "Speed", "Keyframe", "Mask", "Chroma")
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            tools.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { tool ->
                        OutlinedButton(
                            onClick = { onTool(tool) },
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = Panel2Color, contentColor = TextColor),
                            border = BorderStroke1(LineColor),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(9.dp)
                        ) { Text(tool, fontSize = 10.sp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = onReplaceMedia,
            colors = ButtonDefaults.buttonColors(containerColor = Panel2Color, contentColor = TextColor),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Replace media", fontSize = 11.sp) }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = onDeleteLayer,
            colors = ButtonDefaults.buttonColors(containerColor = Panel2Color, contentColor = Color(0xFFFF9D9D)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Delete layer", fontSize = 11.sp) }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, color = Color(0xFFAEB8C6), fontSize = 10.sp, modifier = Modifier.width(55.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = BlueColor, activeTrackColor = BlueColor)
        )
        Text("${value.toInt()}%", color = Color(0xFFAEB8C6), fontSize = 10.sp, modifier = Modifier.width(35.dp))
    }
}

@Composable
private fun ActionBar(onOpenPanel: (String) -> Unit) {
    val actions = listOf(
        Triple("Media", Icons.Filled.Add, false),
        Triple("Layer", Icons.Filled.Layers, false),
        Triple("Audio", Icons.Filled.MusicNote, false),
        Triple("Voice", Icons.Filled.Mic, false),
        Triple("AI Studio", Icons.Filled.AutoAwesome, true)
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0D121A))
            .horizontalScroll(rememberScrollState())
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        actions.forEach { (label, icon, isAi) ->
            Button(
                onClick = { onOpenPanel(label) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAi) Color(0xFF172642) else Color(0xFF141B25),
                    contentColor = TextColor
                ),
                border = if (isAi) BorderStroke1(BlueColor) else null,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 8.dp),
                modifier = Modifier.widthIn(min = 74.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, contentDescription = null, modifier = Modifier.size(17.dp))
                    Text(label, fontSize = 9.sp, color = Color(0xFFAEB8C6))
                }
            }
        }
    }
}

@Composable
private fun TimelineSection(videoClips: List<ClipItem>, onSelect: (String) -> Unit, onZoom: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A0E14))
            .border(BorderStroke1(LineColor))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(43.dp)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Timeline", color = TextColor, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("\u25CF Autosaved", color = GreenColor, fontSize = 9.sp)
            IconButtonMini("\u2212") { onZoom("Timeline zoom out") }
            IconButtonMini("+") { onZoom("Timeline zoom in") }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(start = 100.dp)
                .height(24.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            listOf("00:00", "00:10", "00:20", "00:30", "00:40", "00:50", "01:00").forEach {
                Text(it, color = Color(0xFF697587), fontSize = 8.sp)
            }
        }

        TimelineTrack("\uD83C\uDFA5 Video", videoClips, onSelect)
        TimelineTrack("\u25A3 Image", listOf(ClipItem("B-Roll 01", Color(0xFF315340)), ClipItem("B-Roll 02", Color(0xFF315340))), onSelect)
        TimelineTrack("\u270E Text", listOf(ClipItem("Question Text", Color(0xFF59465E)), ClipItem("Answer Text", Color(0xFF59465E))), onSelect)
        TimelineTrack("\u266B Audio", listOf(ClipItem("Background Music", Color(0xFF59472E))), onSelect)
        TimelineTrack("\uD83C\uDF99 Voice", listOf(ClipItem("AI Voiceover", Color(0xFF3D512F))), onSelect)
    }
}

@Composable
private fun IconButtonMini(symbol: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 28.dp, height = 26.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Panel2Color)
            .border(BorderStroke1(LineColor), RoundedCornerShape(6.dp)),
        contentAlignment = Alignment.Center
    ) {
        TextButton(onClick = onClick, contentPadding = PaddingValues(0.dp)) {
            Text(symbol, color = TextColor, fontSize = 12.sp)
        }
    }
}

@Composable
private fun TimelineTrack(label: String, clips: List<ClipItem>, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .border(BorderStroke1(Color(0xFF1B2330)))
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color(0xFFA2ADBC),
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(100.dp).padding(start = 10.dp)
        )
        clips.forEach { clip ->
            Box(
                modifier = Modifier
                    .padding(end = 6.dp)
                    .height(32.dp)
                    .widthIn(min = 90.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(clip.color)
                    .border(BorderStroke1(Color.Transparent), RoundedCornerShape(6.dp))
                    .clickableSimple { onSelect(clip.label) }
                    .padding(horizontal = 9.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(clip.label, color = TextColor, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun PanelDrawer(title: String, cards: List<PanelCard>, onClose: () -> Unit, onOpenCard: (String) -> Unit) {
    AnimatedVisibility(visible = true) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelColor)
                .border(BorderStroke1(LineColor))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = TextColor, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = null, tint = TextColor)
                }
            }
            Spacer(Modifier.height(8.dp))
            // Simple flow of cards, two per row
            cards.chunked(2).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    row.forEach { card ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(Panel2Color, RoundedCornerShape(9.dp))
                                .border(BorderStroke1(LineColor), RoundedCornerShape(9.dp))
                                .padding(11.dp)
                        ) {
                            Text(card.title, color = TextColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(card.subtitle, color = MutedColor, fontSize = 9.sp, lineHeight = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { onOpenCard(card.title) },
                                colors = ButtonDefaults.buttonColors(containerColor = BlueColor, contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 6.dp)
                            ) { Text("Open", fontSize = 9.sp) }
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun SafetyCheck() {
    Column(
        modifier = Modifier
            .padding(10.dp)
            .fillMaxWidth()
            .background(Color(0xFF10161F), RoundedCornerShape(10.dp))
            .border(BorderStroke1(LineColor), RoundedCornerShape(10.dp))
            .padding(11.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Filled.Shield, contentDescription = null, tint = TextColor, modifier = Modifier.size(16.dp))
            Column {
                Text("Creator & Policy Check", color = TextColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Pre-publish review \u2014 not a guarantee", color = MutedColor, fontSize = 8.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            CheckChip("\u2713 Original contribution", GreenColor)
            CheckChip("\u2713 License recorded", GreenColor)
        }
        Spacer(Modifier.height(5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            CheckChip("! Review repetitive format", YellowColor)
            CheckChip("! Review AI disclosure needs", YellowColor)
        }
        Spacer(Modifier.height(5.dp))
        CheckChip("\u2713 Thumbnail accuracy", GreenColor)
    }
}

@Composable
private fun CheckChip(text: String, color: Color) {
    Text(
        text,
        color = color,
        fontSize = 8.sp,
        modifier = Modifier
            .background(Panel2Color, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    )
}

// ---------- small helpers ----------
private fun BorderStroke1(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)

private fun Modifier.clickableSimple(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)

private fun Modifier.graphicsAlphaScale(opacityPercent: Float, scalePercent: Float): Modifier =
    this.alpha(opacityPercent / 100f).scale(scalePercent / 100f)
